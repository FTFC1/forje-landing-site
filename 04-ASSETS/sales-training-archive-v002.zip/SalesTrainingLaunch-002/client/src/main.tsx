import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

// Initialize FontAwesome
import { library } from '@fortawesome/fontawesome-svg-core';
import { fab } from '@fortawesome/free-brands-svg-icons';
import { 
  faUserGraduate, faBriefcase, faSyncAlt, faClipboardCheck, 
  faMapMarkerAlt, faUsers, faChartLine, faQuoteLeft, faUserPlus, 
  faLaptop, faAward, faStore, faUserTie, faHandshake, faUsersCog,
  faEnvelope, faPhone, faCheck, faBars
} from '@fortawesome/free-solid-svg-icons';

// Add all icons to the library
library.add(
  fab, faUserGraduate, faBriefcase, faSyncAlt, faClipboardCheck, 
  faMapMarkerAlt, faUsers, faChartLine, faQuoteLeft, faUserPlus, 
  faLaptop, faAward, faStore, faUserTie, faHandshake, faUsersCog,
  faEnvelope, faPhone, faCheck, faBars
);

createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={queryClient}>
    <App />
    <Toaster />
  </QueryClientProvider>
);
