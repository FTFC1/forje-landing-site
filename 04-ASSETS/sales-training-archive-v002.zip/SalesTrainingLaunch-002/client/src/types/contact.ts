export interface ContactFormData {
  name: string;
  email: string;
  company: string;
  role: string;
  whatsapp?: string;
  consent: boolean;
}
