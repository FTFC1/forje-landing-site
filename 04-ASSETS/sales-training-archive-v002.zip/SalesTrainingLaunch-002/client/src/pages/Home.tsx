import Header from "@/components/Header";
import Hero from "@/components/Hero";
import WhySalesTraining from "@/components/WhySalesTraining";
import Benefits from "@/components/Benefits";
import Testimonials from "@/components/Testimonials";
import ProcessSection from "@/components/ProcessSection";
import TargetAudience from "@/components/TargetAudience";
import AboutSection from "@/components/AboutSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { useEffect } from "react";

export default function Home() {
  // Scroll handler for smooth scrolling to anchor links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A') {
        const href = target.getAttribute('href');
        if (href && href.startsWith('#')) {
          e.preventDefault();
          const targetElement = document.querySelector(href);
          if (targetElement) {
            window.scrollTo({
              top: targetElement.getBoundingClientRect().top + window.scrollY - 80,
              behavior: 'smooth'
            });
          }
        }
      }
    };
    
    document.addEventListener('click', handleAnchorClick);
    
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Hero />
      <WhySalesTraining />
      <Benefits />
      <Testimonials />
      <ProcessSection />
      <TargetAudience />
      <AboutSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
