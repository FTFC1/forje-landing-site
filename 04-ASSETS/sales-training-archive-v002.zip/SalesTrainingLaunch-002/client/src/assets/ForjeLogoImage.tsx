
export default function ForjeLogoImage({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="/images/logo.jpg" 
        alt="FORJE Logo" 
        className="h-8 w-auto"
      />
    </div>
  );
}
