export default function ForjeLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="w-6 h-6 relative">
        <svg 
          width="24" 
          height="24" 
          viewBox="0 0 24 24" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="24" height="24" fill="#E8F3E8"/>
          <path d="M4 4H20V20H4V4Z" fill="#4CAF50" fillOpacity="0.3"/>
        </svg>
      </div>
      <span className="text-xl font-semibold">FORJE</span>
    </div>
  );
}