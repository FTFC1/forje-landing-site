import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IconProp } from "@fortawesome/fontawesome-svg-core";

export default function AboutSection() {
  return (
    <section className="py-16 bg-[#1E1E1E] text-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="neue text-3xl md:text-4xl font-bold mb-6">About FORJE</h2>
            <p className="text-lg mb-6">
              FORJE is a boutique retail-strategy consultancy dedicated to shaping profitable, future-ready fashion and lifestyle businesses across Africa.
            </p>
            <p className="text-lg mb-6">
              Lagos-based, global standards. Blending decades of retail, tech, and hospitality experience to deliver exceptional training and consulting services.
            </p>
            <div className="flex gap-4">
              <a 
                href="#contact" 
                className="px-6 py-3 bg-primary hover:bg-primary-dark text-white rounded-md transition neue inline-block"
              >
                Work With Us
              </a>
            </div>
          </div>
          <div className="relative bg-[#2A2A2A] rounded-xl shadow-lg p-8 h-full flex items-center justify-center">
            <div className="absolute inset-0 overflow-hidden rounded-xl">
              <div className="absolute top-0 right-0 w-2/3 h-2/3 bg-primary opacity-10 rounded-full filter blur-2xl transform translate-x-1/4 -translate-y-1/4"></div>
              <div className="absolute bottom-0 left-0 w-2/3 h-2/3 bg-primary opacity-10 rounded-full filter blur-2xl transform -translate-x-1/4 translate-y-1/4"></div>
            </div>
            <div className="relative z-10 text-center">
              <FontAwesomeIcon icon={"certificate" as IconProp} className="text-primary text-6xl mb-4" />
              <h3 className="neue text-2xl font-bold mb-2">Lagos-based,<br />Global standards</h3>
              <p className="text-gray-400">40+ years combined retail expertise</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
