import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function WhySalesTraining() {
  return (
    <section id="why" className="py-16 relative overflow-hidden">
      {/* Soft gradient background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-purple-200 rounded-full filter blur-[100px] opacity-20"></div>
        <div className="absolute bottom-0 left-0 w-2/3 h-2/3 bg-purple-100 rounded-full filter blur-[80px] opacity-20"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">Why Sales Training?</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Nigerian retailers face a critical skills gap. FORJE bridges it with practical, localised training.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {/* Stat 1 - Young population */}
          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-white opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10">
              <div className="flex justify-center mb-6">
                <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center">
                  <FontAwesomeIcon icon="user-graduate" className="text-white text-3xl" />
                </div>
              </div>
              <h3 className="neue text-3xl md:text-4xl font-bold text-center mb-3 group-hover:text-primary transition-colors">60%</h3>
              <p className="text-center text-gray-700 group-hover:text-gray-900 transition-colors">of Nigerians are under 25 – massive entry-level talent pool</p>
            </div>
          </div>
          
          {/* Stat 2 - 6 in 10 graduates lack skills */}
          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 to-white opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10">
              <div className="flex justify-center mb-6">
                <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center">
                  <FontAwesomeIcon icon="briefcase" className="text-white text-3xl" />
                </div>
              </div>
              <h3 className="neue text-3xl md:text-4xl font-bold text-center mb-3 group-hover:text-primary transition-colors">6 in 10</h3>
              <p className="text-center text-gray-700 group-hover:text-gray-900 transition-colors">graduates lack job-ready retail service skills</p>
            </div>
          </div>
          
          {/* Stat 3 - 30%+ turnover */}
          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-white opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10">
              <div className="flex justify-center mb-6">
                <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center">
                  <FontAwesomeIcon icon="sync-alt" className="text-white text-3xl" />
                </div>
              </div>
              <h3 className="neue text-3xl md:text-4xl font-bold text-center mb-3 group-hover:text-primary transition-colors">30%+</h3>
              <p className="text-center text-gray-700 group-hover:text-gray-900 transition-colors">annual front-line staff turnover in retail</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
