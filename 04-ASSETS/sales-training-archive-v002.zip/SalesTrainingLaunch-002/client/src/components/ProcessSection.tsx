import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IconProp } from "@fortawesome/fontawesome-svg-core";

export default function ProcessSection() {
  const steps = [
    {
      number: 1,
      icon: "user-plus" as IconProp,
      title: "Sign Up Your Team",
      description: "Register your team for our tailored retail sales training program"
    },
    {
      number: 2,
      icon: "phone" as IconProp,
      title: "Complete Interactive Modules",
      description: "Engage with practical, scenario-based training (online or in-person)"
    },
    {
      number: 3,
      icon: "award" as IconProp,
      title: "Get Certified & Track Results",
      description: "Receive certification and monitor improved sales performance"
    }
  ];

  return (
    <section id="how" className="py-16 md:py-20 bg-[#F5F5F5]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            A simple, effective process to enhance your team's sales capabilities
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step) => (
            <div key={step.number} className="bg-white p-8 rounded-xl shadow-soft text-center relative">
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-primary text-white h-10 w-10 rounded-full flex items-center justify-center neue font-bold text-lg">
                {step.number}
              </div>
              <div className="h-24 flex items-center justify-center mb-4">
                <FontAwesomeIcon icon={step.icon} className="text-5xl text-primary opacity-80" />
              </div>
              <h3 className="neue text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-gray-600">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
