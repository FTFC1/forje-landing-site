import { useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function ContactSection() {
  // Add Tally script when component mounts
  useEffect(() => {
    // Only add the script if it doesn't already exist
    if (!document.querySelector('script[src="https://tally.so/widgets/embed.js"]')) {
      const script = document.createElement('script');
      script.src = "https://tally.so/widgets/embed.js";
      script.async = true;
      script.onload = () => {
        // When script loads, initialize Tally forms
        if (typeof (window as any).Tally !== 'undefined') {
          (window as any).Tally.loadEmbeds();
        } else {
          // Fallback for when Tally isn't available
          document.querySelectorAll('iframe[data-tally-src]:not([src])').forEach((iframe) => {
            const iframeEl = iframe as HTMLIFrameElement;
            if (iframeEl.dataset.tallySrc) {
              iframeEl.src = iframeEl.dataset.tallySrc;
            }
          });
        }
      };
      document.body.appendChild(script);
    }
  }, []);

  return (
    <section id="contact" className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">Register Interest</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Join the waitlist for our retail sales training program
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Tally Form Embed - Styled to look native */}
          <div className="bg-white p-0 rounded-xl shadow-soft overflow-hidden">
            <iframe 
              data-tally-src="https://tally.so/embed/mZyPP0?alignLeft=1&hideTitle=1&dynamicHeight=1&transparentBackground=1" 
              loading="lazy" 
              width="100%" 
              height="450" 
              frameBorder="0" 
              title="FORJE Sales Training Registration"
              className="border-none min-h-[450px] !bg-transparent"
              style={{
                margin: 0,
                overflow: 'hidden',
                display: 'block',
                backgroundColor: 'transparent',
              }}
            ></iframe>
          </div>
          
          {/* Contact Information */}
          <div className="flex flex-col justify-center">
            <div className="mb-8">
              <h3 className="neue text-2xl font-bold mb-4">Contact Us</h3>
              <p className="text-gray-700 mb-2">
                <FontAwesomeIcon icon="envelope" className="mr-3 text-primary" /> commercial@forje.org
              </p>
              <p className="text-gray-700 mb-2">
                <FontAwesomeIcon icon="phone" className="mr-3 text-primary" /> +234 908 328 2287
              </p>
              <p className="text-gray-700">
                <FontAwesomeIcon icon="map-marker-alt" className="mr-3 text-primary" /> 1a Akanbi Disu, Lekki Phase 1, Lagos
              </p>
            </div>
            
            <div>
              <h3 className="neue text-2xl font-bold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary-dark transition">
                  <FontAwesomeIcon icon={["fab", "linkedin-in"]} />
                </a>
                <a href="#" className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary-dark transition">
                  <FontAwesomeIcon icon={["fab", "instagram"]} />
                </a>
                <a href="#" className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary-dark transition">
                  <FontAwesomeIcon icon={["fab", "twitter"]} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
