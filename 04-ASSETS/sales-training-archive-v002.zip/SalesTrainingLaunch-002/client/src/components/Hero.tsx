export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-purple-50 to-white pt-28 md:pt-32 pb-16 md:pb-20 overflow-hidden">
      {/* Background gradient elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-200/20 to-indigo-100/10"></div>
        <div className="absolute -top-24 -left-24 w-64 h-64 bg-purple-300/30 rounded-full filter blur-[80px]"></div>
        <div className="absolute top-1/2 right-0 w-96 h-96 bg-indigo-300/20 rounded-full filter blur-[80px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-8">
            <span className="text-black">Where</span> <span className="text-primary">African</span> <span className="text-black">Retail Meets</span> <br />
            <span className="text-black">World-Class</span> <span className="text-primary">Excellence</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-12 text-gray-700">
            FORJE's Sales Training Academy – Transforming Nigeria's Retail Landscape
          </p>
          
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <a 
              href="#contact" 
              className="bg-primary hover:bg-primary-dark text-white py-3 px-10 rounded-md transition-all duration-300 text-center text-lg font-medium"
            >
              Register Interest
            </a>
            <a 
              href="#why" 
              className="bg-white hover:bg-gray-50 text-gray-800 border border-gray-300 py-3 px-10 rounded-md transition-all duration-300 text-center text-lg font-medium"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
