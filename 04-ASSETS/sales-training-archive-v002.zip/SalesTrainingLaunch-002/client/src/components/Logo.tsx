import React from 'react';

export default function Logo({ className = "" }: { className?: string }) {
  return (
    <svg
      width="140"
      height="40"
      viewBox="0 0 140 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* FORJE Text */}
      <path
        d="M5 5H22V10H10V15H20V20H10V30H5V5Z"
        fill="black"
      />
      <path
        d="M25 5H45C47.7614 5 50 7.23858 50 10V25C50 27.7614 47.7614 30 45 30H25V5ZM30 10V25H45C45 25 45 10 45 10H30Z"
        fill="black"
      />
      <path
        d="M55 5H75C77.7614 5 80 7.23858 80 10V25C80 27.7614 77.7614 30 75 30H55V5ZM60 10V25H75C75 25 75 10 75 10H60Z"
        fill="black"
      />
      <path
        d="M83 5H98V20C98 25.5228 93.5228 30 88 30H83V5ZM88 10V25H93C93 25 93 10 93 10H88Z"
        fill="black"
      />
      <path
        d="M101 5H126V10H116V30H111V10H101V5Z"
        fill="black"
      />
      
      {/* Diamond elements */}
      <rect
        x="125"
        y="20"
        width="10"
        height="10"
        transform="rotate(-45 125 20)"
        fill="#8B5CF6"
      />
      <rect
        x="120"
        y="15"
        width="10"
        height="10"
        transform="rotate(-45 120 15)"
        fill="#9B72CF"
      />
    </svg>
  );
}