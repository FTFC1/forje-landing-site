import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IconProp } from "@fortawesome/fontawesome-svg-core";

export default function Testimonials() {
  return (
    <section className="py-16 gradient-bg text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">Trusted by African Retailers</h2>
          <p className="text-lg max-w-3xl mx-auto">
            Join leading brands that are elevating their sales performance through FORJE's training
          </p>
        </div>
        
        {/* Retail partners flow chart visualization */}
        <div className="max-w-4xl mx-auto relative mb-20">
          {/* Central FORJE box */}
          <div className="w-48 h-14 bg-white bg-opacity-20 rounded-md flex items-center justify-center mx-auto mb-8 relative z-10">
            <span className="neue font-bold opacity-90">FORJE TRAINING</span>
          </div>
          
          {/* Connection lines */}
          <div className="absolute left-1/2 top-14 w-1 h-16 bg-white bg-opacity-20 -translate-x-1/2"></div>
          <div className="absolute left-1/2 top-28 w-3/4 h-1 bg-white bg-opacity-20 -translate-x-1/2"></div>
          <div className="absolute left-1/4 top-28 w-1 h-10 bg-white bg-opacity-20"></div>
          <div className="absolute left-1/2 top-28 w-1 h-10 bg-white bg-opacity-20"></div>
          <div className="absolute left-3/4 top-28 w-1 h-10 bg-white bg-opacity-20"></div>
          
          {/* Partners arranged in a row below with connecting lines */}
          <div className="flex justify-between mt-20">
            <div className="h-12 w-36 bg-white bg-opacity-20 rounded flex items-center justify-center">
              <span className="neue font-semibold opacity-80">SmartMark</span>
            </div>
            <div className="h-12 w-36 bg-white bg-opacity-20 rounded flex items-center justify-center">
              <span className="neue font-semibold opacity-80">Ashluxury</span>
            </div>
            <div className="h-12 w-36 bg-white bg-opacity-20 rounded flex items-center justify-center">
              <span className="neue font-semibold opacity-80">Persianas</span>
            </div>
            <div className="h-12 w-36 bg-white bg-opacity-20 rounded flex items-center justify-center">
              <span className="neue font-semibold opacity-80">Marsden</span>
            </div>
          </div>
        </div>

        <div className="mt-16 max-w-4xl mx-auto bg-white bg-opacity-10 p-8 rounded-xl">
          <div className="text-center mb-6">
            <FontAwesomeIcon icon="quote-left" className="text-4xl opacity-50" />
          </div>
          <p className="text-xl italic mb-6 text-center">
            "78% of retail employees enter the industry as a job, not a career. Our training is designed to change that perception and create passionate retail professionals."
          </p>
          <div className="flex items-center justify-center">
            <div className="flex justify-center items-center h-12 w-12 rounded-full bg-primary mr-4">
              <FontAwesomeIcon icon="chart-line" className="text-white text-sm" />
            </div>
            <div>
              <h4 className="neue font-semibold">Industry Insight</h4>
              <p className="text-sm opacity-80">FORJE Retail Research 2024</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
