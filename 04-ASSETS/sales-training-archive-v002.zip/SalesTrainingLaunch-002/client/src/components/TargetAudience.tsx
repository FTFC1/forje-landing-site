import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function TargetAudience() {
  const audiences = [
    {
      icon: "store",
      title: "Retailers",
      description: "Fashion, electronics, and lifestyle retail businesses"
    },
    {
      icon: "user-tie",
      title: "Store Managers",
      description: "Those responsible for store operations and team leadership"
    },
    {
      icon: "handshake",
      title: "Sales Associates",
      description: "Front-line staff interacting directly with customers"
    },
    {
      icon: "users-cog",
      title: "HR Leaders",
      description: "Those responsible for staff development and training"
    }
  ];

  return (
    <section className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">Who's It For?</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Our sales training is designed for various roles in the retail industry
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {audiences.map((audience, index) => (
            <div key={index} className="p-6 border border-gray-200 rounded-xl text-center">
              <div className="h-16 flex items-center justify-center mb-4">
                <FontAwesomeIcon icon={audience.icon} className="text-4xl text-primary" />
              </div>
              <h3 className="neue text-xl font-semibold mb-3">{audience.title}</h3>
              <p className="text-gray-600">
                {audience.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
