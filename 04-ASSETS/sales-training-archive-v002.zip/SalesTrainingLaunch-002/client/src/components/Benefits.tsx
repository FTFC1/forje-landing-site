import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IconProp } from "@fortawesome/fontawesome-svg-core";

export default function Benefits() {
  const features = [
    {
      icon: "clipboard-check" as IconProp,
      title: "Practical, Scenario-Based Learning",
      description: "Real-world sales situations relevant to African retail environments",
      bgColor: "from-primary to-purple-700",
      iconBg: "bg-white"
    },
    {
      icon: "map-marker-alt" as IconProp,
      title: "Localised for West Africa",
      description: "Culturally relevant training that addresses local market challenges",
      bgColor: "from-purple-600 to-indigo-600",
      iconBg: "bg-white"
    },
    {
      icon: "users" as IconProp,
      title: "Sales, CX, and Leadership",
      description: "Comprehensive coverage of sales techniques, customer experience, and management skills",
      bgColor: "from-indigo-600 to-primary",
      iconBg: "bg-white"
    },
    {
      icon: "chart-line" as IconProp,
      title: "Track Progress & Performance",
      description: "Monitor staff improvement and measure the impact on your retail business",
      bgColor: "from-purple-700 to-purple-500",
      iconBg: "bg-white"
    }
  ];

  return (
    <section id="benefits" className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="neue text-3xl md:text-4xl font-bold mb-4">What You Get</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Comprehensive training tailored for African retail environments
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden h-full"
            >
              <div className="bg-white p-6 relative h-32 flex items-center justify-center overflow-hidden">
                {/* Soft gradients similar to the prospectus */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute bottom-0 right-0 w-full h-full bg-purple-300 rounded-full filter blur-2xl opacity-50 transform translate-x-1/4 translate-y-1/4"></div>
                  <div className="absolute top-0 left-0 w-2/3 h-2/3 bg-indigo-300 rounded-full filter blur-2xl opacity-50 transform -translate-x-1/4 -translate-y-1/4"></div>
                </div>
                <div className={`bg-white h-16 w-16 rounded-full flex items-center justify-center shadow-md z-10 relative`}>
                  <FontAwesomeIcon icon={feature.icon} className="text-primary text-2xl" />
                </div>
              </div>
              <div className="p-6 bg-white">
                <h3 className="neue text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
