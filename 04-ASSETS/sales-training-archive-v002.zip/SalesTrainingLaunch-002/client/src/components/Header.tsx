import { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Logo from "@/components/Logo";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [hasScrolled, setHasScrolled] = useState(false);

  // Detect scroll for header styling changes
  useEffect(() => {
    const handleScroll = () => {
      setHasScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (isMobileMenuOpen) {
        const target = e.target as HTMLElement;
        const isButton = target.closest('#mobile-menu-button');
        const isMenu = target.closest('#mobile-menu');
        
        if (!isButton && !isMenu) {
          setIsMobileMenuOpen(false);
        }
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobileMenuOpen]);

  return (
    <header 
      className={`fixed w-full top-0 z-50 transition-all duration-300 bg-white bg-opacity-95 backdrop-blur-md ${
        hasScrolled ? 'header-shadow' : ''
      }`}
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <a href="#" className="flex items-center">
          <div style={{ height: "36px", width: "auto" }}>
            <img 
              src="/images/logo.png"
              alt="FORJE Logo" 
              style={{ height: "100%", width: "auto", maxWidth: "none" }}
            />
          </div>
        </a>
        
        <nav className="hidden md:flex space-x-6">
          <a href="#why" className="text-dark hover:text-primary transition">Why Sales Training</a>
          <a href="#benefits" className="text-dark hover:text-primary transition">Benefits</a>
          <a href="#how" className="text-dark hover:text-primary transition">How It Works</a>
          <a href="#contact" className="text-dark hover:text-primary transition">Contact</a>
        </nav>
        
        <div className="flex items-center space-x-4">
          <a 
            href="#contact" 
            className="hidden md:block px-6 py-2 bg-primary hover:bg-primary-dark text-white rounded-md transition neue"
          >
            Register Interest
          </a>
          <button 
            id="mobile-menu-button" 
            className="md:hidden text-dark p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <FontAwesomeIcon icon="bars" className="text-xl" />
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div 
        id="mobile-menu" 
        className={`md:hidden bg-white pb-4 ${isMobileMenuOpen ? 'block' : 'hidden'}`}
      >
        <div className="container mx-auto px-4 flex flex-col space-y-3">
          <a 
            href="#why" 
            className="py-2 text-dark hover:text-primary transition"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Why Sales Training
          </a>
          <a 
            href="#benefits" 
            className="py-2 text-dark hover:text-primary transition"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Benefits
          </a>
          <a 
            href="#how" 
            className="py-2 text-dark hover:text-primary transition"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            How It Works
          </a>
          <a 
            href="#contact" 
            className="py-2 text-dark hover:text-primary transition"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Contact
          </a>
          <a 
            href="#contact" 
            className="px-6 py-2 bg-primary hover:bg-primary-dark text-white rounded-md transition neue text-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Register Interest
          </a>
        </div>
      </div>
    </header>
  );
}
