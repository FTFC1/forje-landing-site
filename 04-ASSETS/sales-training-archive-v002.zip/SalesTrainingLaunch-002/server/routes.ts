import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

// Contact form validation schema
const contactFormSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  company: z.string().min(2),
  role: z.string().min(2),
  whatsapp: z.string().optional(),
  consent: z.literal(true)
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint for contact form submissions
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const contactData = contactFormSchema.parse(req.body);
      
      // Store the contact in our database
      const submission = await storage.createContactSubmission({
        name: contactData.name,
        email: contactData.email,
        company: contactData.company,
        role: contactData.role,
        whatsapp: contactData.whatsapp || "",
        consent: contactData.consent,
        submittedAt: new Date()
      });
      
      // Return success response
      res.status(201).json({ 
        success: true, 
        message: "Contact form submitted successfully", 
        data: submission 
      });
    } catch (error) {
      // Handle validation errors
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Validation failed", 
          errors: error.errors 
        });
      }
      
      // Handle other errors
      console.error("Error processing contact form:", error);
      res.status(500).json({ 
        success: false, 
        message: "An error occurred while processing your request" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
