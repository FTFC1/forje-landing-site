# Sales Training Product Strategy Discussion
_Exported on 20/05/2025 at 2:44:30 GMT+1 from Cursor (0.50.5)_

---

**User**

@Meeting 002.md Read this file

---

**Cursor**

You have an incredible opportunity; to pursue my own greatness 🫀.

You asked me to read the file Meeting 002.md.

Summary:
- This is a transcript of a business/product strategy conversation between Nicholas Folarin-Coker and Timilehin Tikolo (and a few others).
- The main focus is on building a retail sales training product/service, with two main pillars: consulting and training.
- There’s a strong emphasis on:
  - Sales training as the MVP (most in-demand, fastest to revenue, most scalable).
  - Gathering raw data via interviews with key stakeholders (store managers, HR, etc.) to localise and differentiate the training.
  - Deliverables: a landing page, a one-pager with up to 25 structured questions for interviews, and possibly a calendar booking page.
  - The need for rapid iteration: ship a basic landing page and question set ASAP, then refine.
  - The importance of understanding assumptions (e.g., number of sales staff, access to smartphones, delivery format).
  - The plan to use interviews (voice notes, calls) to gather insights for the training content.
  - The sales training will be split into two roles: shop floor staff and managers (with managers getting extra admin/KPI content).
  - The six-month business management offer is discussed, but the MVP focus is on sales training for now.

Key actionable points:
- Build a basic landing page for the business (FORJE/Forge).
- Draft a one-pager with up to 25 structured questions for stakeholder interviews.
- Possibly set up a simple calendar booking system for interviews.
- Focus on sales training as the first product, with content tailored from real interviews.
- Use rapid, iterative feedback to improve deliverables.

If you want a specific output (e.g., the 25 questions, a landing page scaffold, or a visual flow), let me know your priority.

🤖

---

**User**

Attached is the prospectus that has been made with branding guidlines. Let's first try to describe and wireframe the landing page. Must be focused on our first module: Sales training. @_chat 2.txt  has the whatsapp chat 

---

**Cursor**

You have an incredible opportunity; to pursue my own greatness 🫀.

**Restated Query:**  
You want a concise, visually-structured description and wireframe for a FORJE landing page, focused on the first module: Sales Training. The design/branding should match the prospectus (black, purple, white, Neue Montreal/Avenir fonts, soft gradients). The content should be direct, MVP-style, and conversion-focused.

---

## 1. Landing Page Description (FORJE Sales Training MVP)

**Goal:**  
- Instantly communicate FORJE’s value in upskilling retail sales teams in West Africa.
- Drive interest/sign-ups for the Sales Training module.
- Look credible, modern, and “simply genius”.

**Core Sections (in order):**

1. **Hero Section**
   - Logo (top left)
   - Headline: “Unlock World-Class Retail Sales Skills”
   - Subheadline: “FORJE’s Sales Training Academy – Built for Africa’s Fastest-Growing Market”
   - CTA: “Register Interest” (button, scrolls to form)
   - Visual: Subtle purple/black gradient background, maybe a photo of a smiling retail associate (matching prospectus style)

2. **Why Sales Training?**
   - 2–3 bullet stats (from prospectus):
     - “60% of Nigerians are under 25 – massive entry-level pool”
     - “6 in 10 graduates lack job-ready service skills”
     - “Front-line turnover exceeds 30% annually”
   - Short paragraph: “Retailers face a critical skills gap. FORJE bridges it with practical, localised training.”

3. **What You Get**
   - 3–4 feature cards (icons or simple boxes):
     - “Practical, scenario-based learning”
     - “Localised for West African retail”
     - “Covers sales, customer experience, and store leadership”
     - “Track progress and performance”

4. **How It Works**
   - 3-step visual flow (horizontal or vertical):
     1. “Sign up your team”
     2. “Complete interactive modules (online or in-person)”
     3. “Get certified, boost sales, and track results”

5. **Who’s It For?**
   - Quick bullets: “Retailers, Store Managers, Sales Associates, HR Leaders”

6. **About FORJE**
   - 2–3 lines: “Lagos-based, global standards. Blending decades of retail, tech, and hospitality experience.”

7. **Register Interest / Contact**
   - Simple form: Name, Email, Company, Role, [optional: WhatsApp]
   - CTA: “Get Early Access” or “Book a Call”
   - Contact details (from prospectus)

8. **Footer**
   - Logo, social links, copyright

---

## 2. Wireframe (Mobile-First, then Desktop)

**[Mobile View – Top to Bottom]**

```
-------------------------------------------------
| FORJE [logo]                                  |
|                                               |
| Unlock World-Class Retail Sales Skills        |
| FORJE’s Sales Training Academy                |
| [Register Interest] [↓]                       |
| [Hero image/gradient]                         |
-------------------------------------------------
| Why Sales Training?                           |
| - 60% of Nigerians <25                        |
| - 6 in 10 grads lack service skills           |
| - 30%+ turnover                              |
| “FORJE bridges the gap with practical,        |
| localised training.”                          |
-------------------------------------------------
| What You Get                                  |
| [Card] Scenario-based learning                |
| [Card] Localised for West Africa              |
| [Card] Sales, CX, Leadership                  |
| [Card] Track progress                         |
-------------------------------------------------
| How It Works                                  |
| 1. Sign up your team                          |
| 2. Complete modules                           |
| 3. Get certified, boost sales                 |
-------------------------------------------------
| Who’s It For?                                 |
| - Retailers                                   |
| - Store Managers                              |
| - Sales Associates                            |
| - HR Leaders                                  |
-------------------------------------------------
| About FORJE                                   |
| “Lagos-based, global standards. Decades of    |
| retail, tech, and hospitality experience.”    |
-------------------------------------------------
| Register Interest                             |
| [Form: Name, Email, Company, Role, WhatsApp]  |
| [Get Early Access]                            |
| Contact: commercial@forje.org                 |
| +234-908-328-2287                             |
| 21 Akanbi Disu, Lekki Phase 1, Lagos          |
-------------------------------------------------
| [Footer: Logo, socials, copyright]            |
-------------------------------------------------
```

**[Desktop View]**
- Hero and form side-by-side
- Features in a 2x2 grid
- “How it works” as a horizontal 3-step flow
- Consistent use of purple/black/white, soft gradients, Neue Montreal/Avenir fonts

---

**Branding/Design Notes:**
- Use the purple/black/white palette, soft gradients as in the prospectus.
- Neue Montreal for headers, Avenir for body (or both Neue if preferred).
- Clean, modern, no clutter. Big, bold headings.
- Use real photos of African retail staff if possible, or abstract gradients if not.

---

**Next Steps:**
- Do you want a Figma wireframe, a React/HTML scaffold, or just the copy for each section?
- Any specific integrations (e.g., WhatsApp, Calendly) for the form?

Let me know your preferred next step or if you want a visual mockup.

🤖

```plaintext
-------------------------------------------------
| FORJE [logo]                                  |
|                                               |
| Unlock World-Class Retail Sales Skills        |
| FORJE’s Sales Training Academy                |
| [Register Interest] [↓]                       |
| [Hero image/gradient]                         |
-------------------------------------------------
| Why Sales Training?                           |
| - 60% of Nigerians <25                        |
| - 6 in 10 grads lack service skills           |
| - 30%+ turnover                              |
| “FORJE bridges the gap with practical,        |
| localised training.”                          |
-------------------------------------------------
| What You Get                                  |
| [Card] Scenario-based learning                |
| [Card] Localised for West Africa              |
| [Card] Sales, CX, Leadership                  |
| [Card] Track progress                         |
-------------------------------------------------
| How It Works                                  |
| 1. Sign up your team                          |
| 2. Complete modules                           |
| 3. Get certified, boost sales                 |
-------------------------------------------------
| Who’s It For?                                 |
| - Retailers                                   |
| - Store Managers                              |
| - Sales Associates                            |
| - HR Leaders                                  |
-------------------------------------------------
| About FORJE                                   |
| “Lagos-based, global standards. Decades of    |
| retail, tech, and hospitality experience.”    |
-------------------------------------------------
| Register Interest                             |
| [Form: Name, Email, Company, Role, WhatsApp]  |
| [Get Early Access]                            |
| Contact: commercial@forje.org                 |
| +234-908-328-2287                             |
| 21 Akanbi Disu, Lekki Phase 1, Lagos          |
-------------------------------------------------
| [Footer: Logo, socials, copyright]            |
-------------------------------------------------
```

---

**User**

use perplexity mcp to iterate on the wireframe. Do 5 searches and create 3 wireframes 

---

**Cursor**

You have an incredible opportunity; to pursue my own greatness 🫀.

**Synthesised from 5 Perplexity searches (see below for research highlights):**

---

# 3 Wireframes for FORJE Sales Training Landing Page

---

## **Wireframe 1: “Trust-First, Local Hero”**

**Hero**
- FORJE logo (top left)
- Headline: “Unlock World-Class Retail Sales Skills”
- Subheadline: “Sales Training for Africa’s Fastest-Growing Market”
- CTA: [Get Early Access] (contrasting purple button)
- Visual: Authentic photo of African retail staff, soft purple/black gradient overlay

**Trust & Social Proof**
- “Trusted by 50+ African retailers” (client logos, local awards/certifications)
- 1–2 short testimonials (with names, companies, photos)

**Why Sales Training?**
- 3 bullet stats (e.g. “60% of Nigerians <25”, “6 in 10 grads lack service skills”, “30%+ turnover”)
- Short paragraph: “FORJE bridges the gap with practical, localised training.”

**What You Get**
- 3–4 feature cards:
  - Scenario-based learning
  - Localised for West Africa
  - Covers sales, CX, leadership
  - Track progress

**How It Works**
- 3-step flow (icons):
  1. Sign up your team
  2. Complete modules (online/in-person)
  3. Get certified, boost sales

**Register Interest**
- Short form: Name, Email, Company, Role, WhatsApp (optional)
- Privacy note: “We respect your data.”

**Footer**
- Contact info, social links, trust badges

---

## **Wireframe 2: “Mobile-First, Action-Driven”**

**Sticky Header**
- Logo | [Book Demo] CTA

**Hero**
- Headline: “Transform Your Sales Team in 30 Days”
- Subheadline: “Practical, localised training for African retailers”
- CTA: [Start Free Trial] (above the fold)
- Visual: Split-screen (local imagery + CTA)

**Value Proposition**
- 3–5 bullet points:
  - Learn from local experts
  - Pay in instalments
  - Mobile-first, offline access
  - Regional certifications

**Social Proof**
- “Join 500+ companies” (logos, badges)
- 1–2 video testimonials (mobile-friendly)

**Lead Magnet**
- “Download Free Checklist: 10 Steps to Upskill Your Team” (email capture)

**How It Works**
- Visual timeline (horizontal scroll on mobile)

**Footer**
- Contact, WhatsApp, address, copyright

---

## **Wireframe 3: “Credibility & Local Relevance”**

**Hero**
- Bold headline: “Africa’s #1 Retail Sales Training Academy”
- Subheadline: “Built by Africans, for Africans”
- CTA: [Request a Demo] (sticky, high-contrast)
- Visual: Local patterns/motifs in background, real staff photo

**About FORJE**
- 2–3 lines: “Lagos-based, global standards. 40+ years’ experience.”

**Features**
- Grid of 4 cards:
  - Localised content
  - Scenario-based learning
  - WhatsApp support
  - Regional payment options

**Case Study**
- “How [Local Brand] Increased Sales by 30% in 3 Months” (metrics, quote, photo)

**Register Interest**
- Minimal form (Name, Email, Company)
- WhatsApp/Telegram option

**Footer**
- Trust badges, local certifications, social links

---

# **Research Highlights (Perplexity MCP)**
- Trust signals: local certifications, client logos, testimonials, regional awards
- Mobile-first: single-column, fat-finger CTAs, fast load, minimal fields
- Social proof: local case studies, video testimonials, metrics
- Local relevance: authentic imagery, local motifs, regional payment options, language options
- Conversion killers: slow load, vague value, too many form fields, generic imagery, weak CTAs

---

**Next Step:**  
Pick a wireframe or mix elements. I can turn it into a Figma, HTML scaffold, or just the copy. Let me know your preference.

🤖

---

**User**

the issue is that we haven't laucnhed so we have no claims yet 

---

**Cursor**

You have an incredible opportunity; to pursue my own greatness 🫀.

**Restated:**  
You want a landing page that builds trust and credibility, but you have no client logos, testimonials, or “proof” claims yet—since FORJE hasn’t launched.

---

## 80/20 Solution: “Pre-Launch Trust” Wireframe

**Key Principles:**
- Don’t fake traction—focus on vision, credibility, and transparency.
- Use “social proof by association” (e.g., founder experience, partnerships, press mentions, or even “inspired by”).
- Make your process, values, and local relevance ultra-clear.
- Invite early adopters to “shape the future” with you.

---

### **Wireframe: FORJE Sales Training (Pre-Launch MVP)**

**Header**
- FORJE logo
- [Register Interest] CTA

**Hero**
- Headline: “Africa’s Next-Gen Retail Sales Training Academy”
- Subheadline: “Be among the first to upskill your team with practical, localised training.”
- CTA: [Get Early Access]
- Visual: Authentic African retail staff or abstract local motif

**Why FORJE?**
- “Built by African retail experts with 40+ years’ combined experience.”
- “Designed for West Africa’s unique retail challenges.”
- “Mobile-first, practical, and ready for your team.”

**What You’ll Get**
- Scenario-based learning
- Localised content
- WhatsApp support
- Regional payment options

**How It Works**
- 3 steps: Register → Get notified → Join pilot cohort

**Founders’ Credibility**
- “Founded by ex-[well-known company] retail leaders” (if true)
- “Backed by experience in [industry, region, or notable projects]”
- “Inspired by global best practices, tailored for Africa”

**Early Adopter Invitation**
- “Help us shape the future of African retail training. Join our pilot and get exclusive access, input, and early-bird pricing.”

**Register Interest**
- Short form: Name, Email, Company, WhatsApp (optional)
- “We’ll only contact you about the pilot.”

**Footer**
- Contact info, social links, “Launching soon in Lagos, Nigeria”

---

### **What to Avoid**
- No fake testimonials, logos, or inflated claims.
- No “trusted by” or “used by” unless 100% true.
- Don’t over-promise—focus on the journey and invite collaboration.

---

### **Extra Trust Builders (Pre-Launch)**
- “Backed by research and local interviews” (if you’ve done them)
- “Pilot partners wanted—get in touch to co-create”
- “Our mission: [clear, honest statement]”
- “Sign up for launch updates and exclusive pilot access”

---

**Summary:**  
Position FORJE as a credible, ambitious, and honest new player. Use founder experience, process transparency, and an open invitation to early adopters as your main trust levers.

Let me know if you want this as a Figma, HTML, or copy draft.

🤖

---

**User**

show me a wireframe of this on a screen and laid out in the chat with uft8

---

**Cursor**

You have an incredible opportunity; to pursue my own greatness 🫀.

Below is a **mobile-first wireframe** for the FORJE pre-launch landing page, both as a visual (UTF-8 box drawing) and a clear, section-by-section chat layout.

---

## **UTF-8 Wireframe (Mobile View)**

```
┌─────────────────────────────────────────────┐
│ FORJE [logo]                               │
│────────────────────────────────────────────│
│ Africa’s Next-Gen Retail Sales Training     │
│ Academy                                    │
│ Be among the first to upskill your team     │
│ with practical, localised training.         │
│ [ Get Early Access ]                       │
│ [Hero image: African retail staff/abstract] │
│────────────────────────────────────────────│
│ Why FORJE?                                 │
│ • Built by African retail experts           │
│ • Designed for West Africa’s challenges     │
│ • Mobile-first, practical, ready for you    │
│────────────────────────────────────────────│
│ What You’ll Get                            │
│ [ ] Scenario-based learning                 │
│ [ ] Localised content                      │
│ [ ] WhatsApp support                       │
│ [ ] Regional payment options                │
│────────────────────────────────────────────│
│ How It Works                               │
│ 1. Register                                │
│ 2. Get notified                            │
│ 3. Join pilot cohort                       │
│────────────────────────────────────────────│
│ Founders’ Credibility                      │
│ “Founded by ex-[company] retail leaders”    │
│ “Backed by experience in [industry/region]”│
│ “Inspired by global best practices”         │
│────────────────────────────────────────────│
│ Early Adopter Invitation                   │
│ Help us shape the future of African retail  │
│ training. Join our pilot and get exclusive  │
│ access, input, and early-bird pricing.      │
│────────────────────────────────────────────│
│ Register Interest                          │
│ [Name:__________]                          │
│ [Email:_________]                          │
│ [Company:_______]                          │
│ [WhatsApp:______] (optional)               │
│ [ Submit ]                                 │
│ “We’ll only contact you about the pilot.”   │
│────────────────────────────────────────────│
│ Contact: commercial@forje.org              │
│ +234-908-328-2287                          │
│ Launching soon in Lagos, Nigeria           │
└─────────────────────────────────────────────┘
```

---

## **Section-by-Section (Chat Layout)**

**Header**
- FORJE [logo]
- [Get Early Access] CTA

**Hero**
- “Africa’s Next-Gen Retail Sales Training Academy”
- “Be among the first to upskill your team with practical, localised training.”
- [Get Early Access] button
- [Hero image: African retail staff or abstract motif]

**Why FORJE?**
- Built by African retail experts
- Designed for West Africa’s unique retail challenges
- Mobile-first, practical, and ready for your team

**What You’ll Get**
- Scenario-based learning
- Localised content
- WhatsApp support
- Regional payment options

**How It Works**
1. Register
2. Get notified
3. Join pilot cohort

**Founders’ Credibility**
- “Founded by ex-[company] retail leaders”
- “Backed by experience in [industry/region/notable projects]”
- “Inspired by global best practices, tailored for Africa”

**Early Adopter Invitation**
- “Help us shape the future of African retail training. Join our pilot and get exclusive access, input, and early-bird pricing.”

**Register Interest**
- Name, Email, Company, WhatsApp (optional)
- [Submit] button
- “We’ll only contact you about the pilot.”

**Footer**
- Contact: commercial@forje.org | +234-908-328-2287
- “Launching soon in Lagos, Nigeria”

---

**Ready for Figma, HTML, or copy draft—just say the word.**

🤖

```plaintext
┌─────────────────────────────────────────────┐
│ FORJE [logo]                               │
│────────────────────────────────────────────│
│ Africa’s Next-Gen Retail Sales Training     │
│ Academy                                    │
│ Be among the first to upskill your team     │
│ with practical, localised training.         │
│ [ Get Early Access ]                       │
│ [Hero image: African retail staff/abstract] │
│────────────────────────────────────────────│
│ Why FORJE?                                 │
│ • Built by African retail experts           │
│ • Designed for West Africa’s challenges     │
│ • Mobile-first, practical, ready for you    │
│────────────────────────────────────────────│
│ What You’ll Get                            │
│ [ ] Scenario-based learning                 │
│ [ ] Localised content                      │
│ [ ] WhatsApp support                       │
│ [ ] Regional payment options                │
│────────────────────────────────────────────│
│ How It Works                               │
│ 1. Register                                │
│ 2. Get notified                            │
│ 3. Join pilot cohort                       │
│────────────────────────────────────────────│
│ Founders’ Credibility                      │
│ “Founded by ex-[company] retail leaders”    │
│ “Backed by experience in [industry/region]”│
│ “Inspired by global best practices”         │
│────────────────────────────────────────────│
│ Early Adopter Invitation                   │
│ Help us shape the future of African retail  │
│ training. Join our pilot and get exclusive  │
│ access, input, and early-bird pricing.      │
│────────────────────────────────────────────│
│ Register Interest                          │
│ [Name:__________]                          │
│ [Email:_________]                          │
│ [Company:_______]                          │
│ [WhatsApp:______] (optional)               │
│ [ Submit ]                                 │
│ “We’ll only contact you about the pilot.”   │
│────────────────────────────────────────────│
│ Contact: commercial@forje.org              │
│ +234-908-328-2287                          │
│ Launching soon in Lagos, Nigeria           │
└─────────────────────────────────────────────┘
```

