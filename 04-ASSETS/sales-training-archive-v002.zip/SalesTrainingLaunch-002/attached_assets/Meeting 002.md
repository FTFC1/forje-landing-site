Speaker 1  
One iced mocha. But can the ice mocha? Have an extra shot? I

Timilehin Tikolo  
Hey, bro, Yeah, I'm good

Nicholas Folarin-Coker  
In this coffee shop around the corner. Okay for the the tribe, I was about to send off one on bang, off an email, and then I'll come back and I'll send it. How are you? I'm

Timilehin Tikolo  
okay, man. I'm just trying to, you know, just like, get on as much about that project as possible.

Nicholas Folarin-Coker  
Yeah, because it's so anything your baby just just get zapped. Yeah.

Timilehin Tikolo  
So and I bought like, some actual three meetings from like 130 on me. Obviously I'm treating that as like my part time job as you can Yeah, I haven't really done anything for them this morning. I'll go to the beaten. Do I need to do?

Nicholas Folarin-Coker  
Yeah, you're not trying to go over and above,

Timilehin Tikolo  
focusing on my So, with this, we've obviously got this website we're trying to do, and I'm looking at, you know, academies we should start pitching to. Well, obviously this is just one side, like there's two other things, which is, like, aside the academies, obviously, whenever they come and partner or decide to give us any kind of accreditation, that's cool, but on the other side, we need to develop our own training, you know? Yeah, because if you don't accredit or whatever, it's not

Nicholas Folarin-Coker  
gonna stop us. Yeah, I we need to, we remove the digital first. These guys are not so, yeah,

Timilehin Tikolo  
yeah. So it's like, I inside drawing up the framework for all of that, which would be like, cool. There's the front end stuff, which is like sales training, and then there's the back end stuff, like inventory management, buying, what more? What more? The easiest, the one that's most in demand right now is sales. But then the idea is like, maybe, if we spend the next one or two months trying to build out that module and look at exactly how we're going to deliver it, then, you know, by like, you know, August, September, we start building out the sort of the other departments.

So that is for the what we're trying to build out on, on the modules. So we need also sent you, sorry, bro, I also sent you the, you know, like the, oh, I think, actually, you know, so the guy, one of the guys that we, I met on Friday, he sent a message on the weekend, And let me actually just read it to you, Tim, so that you it's quite it's quite interesting. So he's closed, um, so essentially, just to give you backstory on this guy, quickly, he runs a brand called the band, called a Thomas. It brought about 35k followers on Instagram. It's like a tailoring business. So, you know, like captains and whatnot. He has Indian tailors. That's like quite a strong USB for him. And his business is not heavily dependent on Nigeria, which is good for him. He has, like, operations, like actual physical stores in about four countries in Africa. I think Kenya, Sierra Leone, Nigeria, and Guinea, or somewhere like that. So his mother is very much like I'm spreading myself across the African continent. But then he so, yeah, that day, when we spoke, he basically was saying he wanted an all in almost an all in one solution that will cover everything from from like training to those processes that the team should have to like the requirements for each, you know, for a store, in terms

Nicholas Folarin-Coker  
of SOPs and yeah,

Timilehin Tikolo  
exactly then even like the roles and the store, the guys that go outside the stores.

Nicholas Folarin-Coker  
I mean, fair enough, it's not, it's definitely not some it's definitely something that we can do. But it's, it's it's more. And you'd have to know that it's more, because what, what he, what you just said to me, is basically without having to purchase physical things setting up, right? It's the kind of thing that, if he had this, and he had someone that he thought was diligent, yeah, they could open up a new branch for him, and he would learn with confidence that, like, which is like, actually quite a costly affair. So, yeah, worry

Timilehin Tikolo  
about. And this is the now I'm going to read you the message he sent on the weekend, Steven, so he goes, I guess they were in a conversation before, before, Stephen forward says to me, but where I pick you up from, because I'm also open to you taking over the entire front end of the business for six months, my team will support the back end. I have a CEO, HR CFO, Media Production Manager and the Indian trainer. I've also introduced colours glasses and other small item products from China. So it's the market and sales that's remaining, and it's not just about telling me what to do, because, to be honest, I'm tired. I just need, what I think I need is just to take the wheels and do it. We can start with a six month contract. You can also share a proposal of profit sharing, if you like, looking forward to your proposal. So obviously this is like another thing that,

Nicholas Folarin-Coker  
yeah,

Timilehin Tikolo  
it's full, it's full business management. It's not just Yeah, yeah, but it's essential business manager, because it's like, okay, you know, we're gonna have to go in there diagnose the business, what's working? What's on working? Yeah, we'd have to visit Yeah. And then you start building out. So it's like, there's just so many things coming up. And obviously this guy, he's one of the two people we met that day. He was one of the two who was very keen on the training to be working simultaneously on building out our training and whatever, at least to some decent level where we have a good enough product to start training sales associates and monitoring their progress and making sure that they're actually doing what they learn. But then on the on the other side of that, we need to be able to go into a business and be offering some sort of 360 degree solution? Yeah,

Nicholas Folarin-Coker  
so this is how, like, obviously, it's not a bad problem to have good people, basically, without putting a figure. And they're like, I just want to throw money at you to solve my problems. This is a painful enough problem that I'm willing to give you a business essentially, for six months. So I think it's a good thing. What we need to do is, is continue to think, like, in a product, like, way. And although they have all of this like, oh, I want everything, yeah, they want everything, because what they've realised is that, oh, this is someone who I can't I can't find this type of person elsewhere, because they would be in America, working for Nike, working, do you know, I mean that that's how he's looking, and that's why he's saying, I, in my opinion, based on, like, that's a big thing for someone that you haven't done stuff, and then, no, no, please. We needed that bad, which is good. But the reason why I'm saying we have to have a product view on it is that, if we develop, and you already said this, if we develop a 360 plan, we only get to try out once. I'm not against the six month thing, but What's better is that, okay, what is a 360 plan? It's comprised of five things, right? Let's say it's training in its foundation. Training one, it's sales training to its so, yeah, it's SOP tailored to that individual business, which is like a premium service that we provide. Then it's like a technical order of of the systems that they use, gap analysis. So regardless of what software they decide to go for what we recommend, which obviously can provide a kickback for us as well, they know why they're buying it and not. It's not just because the person who has the much the most clout in the room is saying we should go for it, because literally, that's what I've I've seen at my channel and bro, it's only because they don't, they don't have, like, a quantified way to view what they've lost. They're not paying by it. And by splitting it out like that, we can then actually have like, you know, a document that details like so in product, there's a thing called a PRD, which is a product requirements document, yeah. And if we, if we're able to do that, then we can, we're able to look at everything and say, what here is redundant. That's what what I literally the thing that I was building today, that's literally what I did. I discussed what I wanted, and I built out a flow. I then said, What is redundant? And I just kept doing that until I was like, Okay, this is half decent, and like, as a result, I've built, I've built something as well is more useful for me than what I previously was going to build. One, because I'm leveraging other platforms, and two, because I've asked what has been done, and I've gone through this, like, step wise process. So I'm not, I think the more important thing for us to know first of all is like, how, how do you want to divide up your time? Because it's all very well me saying, Oh, this is amazing. Yeah, bro, let's, let's go for the six months. So this is the cold one as well. Yeah, can you just put it in the fridge? So when I'm leaving up, so thank you. What's it called the Yeah? Because if you're, if you say, well, as much as it's a good idea,

Timilehin Tikolo  
you're,

Nicholas Folarin-Coker  
how can I Okay, if you said that, you can't be going to Guinea right? Because this guy only wants it that whoever is going, or for both going, is only in the week, and obviously I can't, I can't go during the week, then it does. It's not really a company. We have to. Our conversation is, either, are we still going to do it and do it in a sync enough way, or, you know, is it something where he'll pay for us to do these trips on the weekend? In which case, yeah, I can go, because you're between the two of us, you have, in 24 hours, a bit more freedom over your time, especially moving forward. Do you know, I mean, I don't want to, I don't want to, like, assume something, and then actually, it turns out that you need to be a bit more on ground, because stuff to begin with, all because, you know, you've got some family things so that that's what and personally, if you're wondering where I stand, I feel that what we should always try to front load. So it should be a thing where, okay, on the contract you're paying for us to fly to one location that you want, either a new locations spun up with always an existing business already. I we recommend doing an existing business because there's so many political things that we don't know. There's cultural things we don't know. Also, we should probably pick a country known for slightly more like submissive people than Nigerians, just because we're coming in and effectively going to be telling them, like, management told us that, not like that, but that's how they'll see it. Yeah, but yeah, I think the first thing is, like, if, if he said, Okay, sweet, 50,000 pound contract, but you have to spend the next two weeks in Kenya. Like, let's start there. Would you do it? Let's say not the next two weeks. Let's say the next few weeks, assuming that you finished.

Timilehin Tikolo  
Yeah, yeah, I'll do it, but I know that that's not what you would say, but I'll do it.

Nicholas Folarin-Coker  
Okay. What do you think are more realistic?

Timilehin Tikolo  
Why? So I know a lot of things. I know a lot of these Nigerian businesses. They say they want this. They want that. They want that. Then if they start seeing cost, they start like, holding back a bit. They want more evidence. So first of all, just on the back of that, I that's one of the reasons why I don't think travel will even be on his calendar. Will be more like, okay, yeah, the store in Lagos. Let's do you know? I mean, let's

Nicholas Folarin-Coker  
say, Okay, what did you know where the store is?

Timilehin Tikolo  
There's one of there's one on the main I think there's one on the island as well. Maybe, I'm not sure.

Nicholas Folarin-Coker  
I mean, I think that saves a lot of, like, logistical, yeah, early, early growing pains, to be honest. Yeah, cool. So then it's my next, my next thing, right? Because now I think what we need is some way so that we can because maybe this is the thing that's like confusing between the perspectives than what we're talking about, because there's two pillars on the perspectives, which is the training.

Timilehin Tikolo  
Yeah, and so what do you say the second consulting and training,

Nicholas Folarin-Coker  
consulting and training, but then within that, where we're now talking about different pillars, because we have, what we have is, I think foundational training and sales training are separate. And the reason why is because you probably want everyone to do the foundational training, but only certain people do the sales training. But if you bring, bring the two of them, then there's people that won't gain from that. And generally speaking, I think we need to decide what is, what is the biggest value point by your expert opinion, and then we have to get people to conform with that, because there's no point us going for something that we think is less valuable just because these two people want it, because we can sell those two and say, like, of all of the things that we can do for you, for example, the sell, the sales training is the is your biggest, is your fastest path to increase revenue. And then we say, Look, this is, we have a plan for it, and we'll pilot it with you guys, and we'll give you a discretionary price. And this, this, this, this, and this is the revenue chat. And then we just focus purely, first on getting the content down once you get the content. And when I say the content, I don't mean like the deliverable of like how. I mean like the raw data. The raw data is like me interviewing you. The raw data is me perhaps interviewing a couple other key players in terms of what's helped them with sales locally, and then we cross reference that with, like, what the general material says. And then that gives us our localised content. Then we can decide how best we deliver this content. Now that we do know, I mean, we have the whole thing, because if we don't have the we don't have the raw material, then we're kind of, like, it's, that's how people produce, like, it looks nice, but it's not actually valuable, and then it's at the work.

Timilehin Tikolo  
So one thing just, just in line, the way I picture, there's two things like one in this, this is what we should do. So the sales side, um, we need to still build it out, because we're not only building it for these guys, we're building it for everyone. So it's like this job for us. All the things we said, we still need to be quiet, and even if we even will be relevant to these people. Because, again, if you have stores outside Nigeria, and we tell you have this training that is digital, and they can even use it for the other stores, it also adds to the uniqueness of what we're offering. I think 100% we need to do that, okay, on the side of business management running and whatnot. Yeah, I agree with you, like it will be demanding, but I think, yeah, maybe I need to maybe that one I can try and bring some a bit more, and if I can, like you've suggested, maybe do on a pull out, like a plan, just somewhere first and I look at it where it's like, okay, if you see first month, we're going in your stores, or looking at even if it's just a store in Nigeria, and then you're giving us data for other stores, like your best seller, like diagnosing your current state analysis, almost like, yeah, we can Yeah. How many stores, how many days? What's your revenue? Or your best sellers are your cap, you know. Then we start looking at SOPs, you know, like, and then we do the training, and then maybe, like, fourth month, then it, you know, it kind of do something like that. But I know the main thing, so it's like that one we can still do, because it ends up resting like, usually, like you said for me, maybe by July, whenever, and I have more time, it's like two days. I'll just put my mind on what's going on with the business. What are you guys doing? You know, I mean, and then we, like, I can get, or we, we can manage that like that, but sales thing will be the biggest, because it's not even just these guys that need this training, this life, everyone, that's how. But I know that there's a lot that's gonna like we need to figure out sales training, because it's like, apart from being this office and the platform, or whatever it is and the content, which is going to take a lot of time. Like you said, it's also then, like, if one to make it hybrid, because we have facilities to train, you know, in the office, like in the uni offices, the conference room, some people in there. But one is like, how do we also then make sure, like, how we following up the name that you know, doing what we've asked them to

Nicholas Folarin-Coker  
do? That's fine, I think, I think so. The reason why I was asking like this is that I think it was first Okay, let us establish what you know, gun to your head. You can only release one product. What is that product? Is sales training? Fantastic. The next thing is, what are our assumptions around the sales training that we need to clarify or confirm? And then, what are the perceived challenges? So it's like before we even get into it, oh, how do we know that people aren't lying? How do we collect data? How do we make sure that we have access to the tooling that they use, so that we don't have to keep asking for permission for things all the time. These are the things that, like, don't worry about that. Like, that's, that's part of, like, the technical what you wanna call it, it's a constant thing you have to do when you're releasing a new feature. So that part, I can, I can lead us. But if we're saying, like, Okay, actually, everything, and that's a big as a big move forward, because that obviously also informs, like, what the focus is in, like, all of our documentation, or not documentation, all of our materials now, right? So if, if we when, we then start talking about the website, although we're seeing the pillars, you know, we know that we're seeing coming soon, and we say that the focus right now is sales training. Yeah, someone, we just these are like, what the sales training? Right? It's sales training. Everybody is sales training for the people who are literally communicating with the customer in person training, email marketing is, do you know? I mean, yeah,

Timilehin Tikolo  
so what we're focusing on? So again, like you said, there's many aspects. What is most crucial for most people Nigeria, that I know is online staff, sales training. So okay, talking to customers, and then maybe even you can, like, put, like, frontline staff training, and then, like, maybe boutique management, because then there's also gaps in, like, a manager, the managers don't even know what a store manager should be doing. But I think it's even two roles, yeah, yeah, yeah. Well, it's two, yeah, it's two roles. Just one's a bit more advanced than the other, but they need, like, the manager needs all the training that the salespeople are going to get as well, just some additional level of, like, some of the more administrative things that you'll be looking at as a manager, in terms of KPIs and stuff. But that's where it stops. I think if we can even have a very strong product for that, that is like, clear and like, this is how we deliver it is how long it takes to produce, actually making use of it. We check it with you in one quarter to see how it's going, you know. And it's like, we have those things, I think we would, would be booked out before we even,

Nicholas Folarin-Coker  
yeah, no, that's, that's common. I don't like, I didn't really see a problem with that. I'm just thinking, like, Okay, so for, okay, I'll give an example. Why we do the assumptions thing I'll give, I'll give an example. So assumption, I assume that there are under 10 um sales people on that will join the course right as a result. If that assumption is true, quite literally, for the first cohort we You can literally have it that every week you get given three scenarios and you have to record you like you have the scenario on your phone, and you have to record a video of you going through the scenario, and you submit in our portal, or you just send the video to like a private WhatsApp number, and then like the actual or in the community that say privately to your tutor, and then that person will watch it and say, oh, actually You need to do this. Oh, you didn't do this. Oh, you came across this way. Oh, this is like, but if it's 50,000 that we that doesn't scale, right? So that's why the the assumptions and challenges are like, they're intertwined. And you and it might be an assumption is that people, everyone that is on the shop floor, has a smartphone, and actually that they don't, you know, I mean, like we have to, that's why we map the assumption. So we make sure that we build something for the person in mind and not who we think they are in our minds.

Timilehin Tikolo  
Yeah, no, for sure. And I think I'm very happy for us to do that. I think myself. You know myself. I can give you a lot of information. But luckily, Steven is also extremely knowledgeable on this one. Because I wanted, I can give you everything, I mean, I document that, then we can just send you some time again, I don't know, the weekend or whenever, like, that's when also then, like, take on both what he's saying as well what he's seen and both of us. We have a huge life, yeah,

Nicholas Folarin-Coker  
a wealth of knowledge. Yeah,

Timilehin Tikolo  
that's how you want us to proceed. Okay, let's start with the song,

Nicholas Folarin-Coker  
yeah? Because we'll do the same thing with, of course, as well, right? It will be, it will. Because what we'll do is, I will act like the dumbest, the world's dumbest person on retail sales. And I would just ask you every question, all the things like this. And obviously, everyone who's actually already working retail so will know more than me, but that I will be able to get the nuance stuff because I actually don't know. And then that will help us build a more new, friendly course, as opposed to one that like, because there's not, if you, if you've been too long in something like, there's things that I do that I can't, I won't know to explain to someone, but I will if I, if someone else will ask me about, oh, yeah, the way it works is like this,

Timilehin Tikolo  
you know what? Actually, I think once you what we should do, maybe I don't know how you want to do that, maybe, obviously, with AI, right? If you have a list of the structured questions you want to ask, like one to ensure that there's interest, or beyond interest, because we know there's interest. So don't spend too much time on knowing whether you're interested in doing but it's more like, where are the challenges? What are the gaps? What would you want to perform for the client. Yeah, that you would ask, like, the questions you would ask, like, because I'm assuming it'll be almost like an interview, like, would be a conversation.

Nicholas Folarin-Coker  
Um, yes, but okay, I'm saying two things. So there's, there's me getting knowledge from you that forms the sales training, yes. And then there is us having a form for qualifying customers, essentially, as in, like, clients. So like, how big is your store?

Timilehin Tikolo  
Oh, no, okay, fair, I get that. Oh no, I wasn't talking about that, yeah. Oh, okay. I was looking more on the first part, like, we need to know.

Nicholas Folarin-Coker  
Oh, I can. The thing is, right, I can. It depends if you want to be efficient or you want to be fun. So I can give you all of the first pass questions that I can, I can say roughly I need this. Then you can send them to but the reason why, and we can, what we can do, is you get those questions, you just sit down and Voice Note as much as you can, and then you send me that voice note. Cool. But then in real life, what actually happens is you have those questions and you have a bunch of follow up questions, and so it depends. We can even have like two parts.

Timilehin Tikolo  
Is what? Because I wanted to be like, as standardised as possible, right? Because I'm now thinking, rather than just me and Steven, that's I want to subscribe. I want to get like, four different people to do this. Steven is one person because HR of, let's say honest, because she also has a different perspective thing. And then I'm an HR person I know that's also called in abstract currently, who can speak to the same thing? Yeah, to do a call. I mean someone from smart mark as well, like, even Apple himself, because he was having it here, right? Five people.

Nicholas Folarin-Coker  
Yeah. So I just want to know, in your opinion, is it, are we trying to be way too efficient. And actually, I need to have like, five hours of phone calls with people individually, so that they are truly engaged and that they because, you know, I mean, some people like you, I know I can send you a question, because you know what I'm gonna do with it. You're gonna answer that question as if I asked you in person and you had lots of time to answer for other people, they might not,

Timilehin Tikolo  
yeah. I think we might need, like, yeah, that's okay. There's certain things like zoom calls or whatever we just, we just don't give us 30 minutes, like, Saturday morning, what day works for you, what time works for you, Into or One, whatever we can literally,

Nicholas Folarin-Coker  
like, I can make a phone for that. We

Timilehin Tikolo  
can send them questions before and just to look over them, I have an idea. Okay, most important, they're not gonna be typing it. So it's like we get on the call like this, the notes of like them, yeah, ask the follow up questions. Ask everything we need to know. We have all the information transcribed after

Nicholas Folarin-Coker  
Sure, we should probably just like me up, yeah, that's

Timilehin Tikolo  
what I'm saying. So it's like different, because obviously the HR baby inspired that one would just probably do a call like today. I mean, like, just ask, give me 30 minutes at the time, doing my house. You know? I mean, that was difficult. Ibu, we can do in a cafe. Steven will get somewhere lucky. So,

Nicholas Folarin-Coker  
yeah, this is good. I think, I think then in this case, so we've identified the product that is the like, No sir, that's the sales training. And we said that it breaks down into two rows that being the operational stuff on ground or on floor, on shop floor, and then their managers. Then now what we're talking about is designing how we want to do our research gathering or knowledge gathering or information sharing. Yeah, thing we're going to have the questions pre written. They can look over those. Then we ask for 30 minutes of someone's time. Yeah, varying in the amount of time and varying in the form, whether it's online, whether it's in person, whether it's casual, remember it's formal. Once we have that, I think we'll be in a good position for doing the first like draft of this is all of the information, and that's that's then when you and I will sit down and be like, is is this crap, or is this like half decent? And then from there we can, we can start to piece together, at least like an outline of a course, and then we can think about how we deliver that. Now, what I want to know is that course, and the fact that it's going to be for sales training and all of these other things is obviously very key to like internally, the actual product, what, and because I'm this, is so this is an assumption now that I'm asking you to confirm it tonight in my head, that content makes building a landing page that actually speaks to The audience a lot easier. So do you think waiting for that and then having the landing page? Or no, we just need a landing page so that they can click on something when the pitches are happening. Because obviously we're talking about two things. There's product development, and then there's business development,

Timilehin Tikolo  
a website. Yeah, oh no, no, no. I think, you know, I think we still need, because, you know, what we're trying to do is like we're tacking on different ends right now. Oh, sorry, bro, just Hold

Nicholas Folarin-Coker  
on One Second. You.

Timilehin Tikolo  
Sorry. I'm

ft, sorry, can you Hear me?

Nicholas Folarin-Coker  
Hello, yeah, yeah. Acne,

Timilehin Tikolo  
sorry, sorry. Well, this dispatch guys giving him stress every day. So what I think we need now is we need to list the structured questions that we want to ask to understand, one like, obviously, how we're going to deliver the content, what we think like, how people, what will people want from a sales training course I work, what gaps they wanted to address are the one, how do we want to track the changes in behaviour and performance afterwards? And just like, you know, what would be different from a regular sales training? How would be delivered, whether it's hybrid, in person, whatever digital, I think once we have all of that gone, more than enough to grow, and that's what the questions now on the on the last thing we're talking about, just before I went, was whether we needed a landing page. And I was saying, Yes, we do a basic landing page, because if we're trying to do everything or not everything I want, we're trying to just start simultaneous things at once. Remember that in all of this as we're building this training, but also reaching out to these brands, right this these academies, which is what I'm about to do, to like pitch to them, to say, Look common, accredited. What we're doing like, you know, align with those sort of thing. So these guys will need to at least see something about forge online. You know, I'm almost like thinking, Do you think it's best for me not to even pitch yet. Just identify people want to pitch you and wait maybe to the end of the week, or whatever, once I climbing page to then start pitching to that least they can like, Google and see something on Forge, or, let's just go ahead and like, send out this pitch, this pitch emails, and then we'll see how that goes. So I think that's, that's kind of why I was saying, like, Okay, we're good with, like, a basic running page about Forge, or we're consulting blah, blah, blah fan, consulting and training. Contact us for more information.

Nicholas Folarin-Coker  
Okay, so I obviously don't want us to delay. I'm not, I'm not with the today, but I do think we should wait just that. We shouldn't leave as quickly as possible. The reason, reason being, is that I think we'll get a slight if, if we just try and do iterations, right? So I will make the shittiest thing I can spin up like today, right? Then we'll be like, This is crap. What the fuck is this? This is this. This is this. Don't do inspiration to iteration free. So by the end of the week, and then if you send those messages on Monday, what we probably would actually have had by Monday, then this will have the questions, we'll have the landing page, we'll have the people like in the process of answering those questions, and we probably also would have therefore been able to iterate on what these pitch emails are.

Timilehin Tikolo  
Definitely we've done. We've got the we've got the prospectus ready so that, yeah, some work out of the way. Anyways, we can just park that. Once I have a bit more, we can then send it up. And alliances. We do is yeah and try and get these questions and whatnot done so that I can then start once I have a question as we align, and then I'll start reaching out to people to ask about when this week, they might be available for like, 30 minute conversations once they align with

Nicholas Folarin-Coker  
Just to make sure that we are aligned. For completeness, I'm gonna say, off the top of my head, the areas, not the actual questions, the areas that I want the questions to cover. And you can tell me if I missed anything. So it's gonna be some questions. Let's say, first of all, we want it to be 25 questions Maximum, or do you think that's too many?

Timilehin Tikolo  
It should be fine. It should be fine. Okay, so

Nicholas Folarin-Coker  
let's do 25 question maximum. So, and this is for specifically for the sales training, not whether this person is a good client or not. We have a so we'll have to do a separate one for that, because otherwise, okay, specifically for the cells training. So I think we're going to need, like, first of all, some temperature checks, right? So your temperature checks are the things that like, get people to kind of like, focus and talk, like, let's say, fucking around, and do whatever it was they were they were doing at the same time. So your temperature checks are, like, on a scale of one to 10, how much would a 15% boost in sales help you? Yeah, right. Then, between multi select, which of these do you personally feel is the reason why your sales is not doing so well, right? So that's like a temperature cycling. So there'll be a number of temperature check questions,

Timilehin Tikolo  
then

Nicholas Folarin-Coker  
basically some something to kind of gauge like what the current understanding of sales like is. So for example, what is your you could say this is all temperature checking back. What is your current like sales methodology, from like, we use pressure sales tactics to we let ourselves, people do whatever they want to. We have none. Everyone does their freestyle. As long as you get you bring back this, you bring back this cool and like, what channels that you say, that selling on, but that, and the reason why I'm asking you what? Yeah, because that determines, like, whether we need a whole email marketing thing.

Unknown Speaker  
Yeah, 100%

Nicholas Folarin-Coker  
Um, what else We're also going to Need? I

Unknown Speaker  
doesn't take

Timilehin Tikolo  
Long. Yo. FDA, yeah,

Nicholas Folarin-Coker  
yeah,

Timilehin Tikolo  
it's very he's done now, cool.

Nicholas Folarin-Coker  
So yeah, basically, I think I was just going through the different sections. So saying temperature checking something to like, gauge their current like, position with sales, or their sales maturity, I think is a better way to put it, less things like, what's their what's their sales methodology? Or is everyone freestyling? Then maybe this is an easier question for the actual question I'll just ask you. It's everyone that's going to be filling this out, everyone that we're targeting where we're specifically looking at physical goods. We're not looking at any digital products, even if they sell online, it's still physical goods.

Timilehin Tikolo  
Yeah. Okay. Yeah. Okay, cool. Um, I think, I think for this, though, I get, I get what you're trying to do, like, thinking into, I think the best thing would be to do, like, obviously, like, an AI,

Nicholas Folarin-Coker  
yeah, we'll do drafts. It's more that I just want it to pick up on this part so that then, okay, sweet, but yeah, no, no, I know what you mean. It's just, I'm, like, while we're here, I'm trying to squeeze out like, as much as I can in our thinking. And then it can be, yeah, what I think we'll have to ask, like, to like, do either, do they all have smartphones, or are they willing to give smartphones? Because, you know, we need, we need some kind of way to deliver in a way that's not we look because we don't want the excuses like, Oh, my system is down. Like, fuck off. Like, on Instagram all the time, but if it's something that everyone has to log into, some LMS, that's not mobile first, it's not like they will 100% make excuses, and then it would be like the adoption rates, that's more thinking About. Yeah, okay, but I think that still works. Do we want to have any questions around pricing in the questionnaire,

Timilehin Tikolo  
pricing for

Nicholas Folarin-Coker  
the or is it just purely about just gauging where and where people are? What issues do they think there are in sales? How they think their team will be most responsive to training, or in what form? Yeah, they think their team will be most responsive to training, and it's like, it's nothing to do with the numbers.

Timilehin Tikolo  
Yeah, I don't think that. Yeah. I'm not Yeah. That's not the pricing this one because, like, it may, actually, we may not really matter for like, obviously, like Steven still just want to give us information, but like someone like Aziza, who is the HR person Smart in right now.

Yeah, what she's asking for, because she might not start thinking, Oh, I'm asking for too much before they come and say, Whatever, let's take all the information and we can then figure it out how to price it after

Nicholas Folarin-Coker  
Okay, no problem.

Timilehin Tikolo  
So yeah, I think let's just have the questions, once we're good on that, I can then schedule the time people. Yeah, I'm even thinking of it. Actually, this guy has asked us to do this entire management. I might even ask him to do sessions also that he also see feels

Nicholas Folarin-Coker  
no 100% 100% anyone who just had, anyone who's done a big ask, we need to, like, start getting them to do a small favour. So it's like, I know you're busy, but can you hop on this call? I know you're this, but can you hop on one? They'll feel like they're being brought along. And so even if we turn around and we build like, we say, like, this is how much it costs, and it's expensive. Luke, I nearly put in effort, but no one else is winning this effort in this part of the world, like and any people who are putting in this effort, like the other side of the world, their price tag is still more expensive because of the denomination, like their currency,

Timilehin Tikolo  
yeah. So I think, yeah. So I think if you can, even if I, you know, if we have a deadline, like by Wednesday, I should have locked in, you know, obviously, once we got the question, I would have gotten questions at least at the latest by Wednesday, if not by end of tomorrow or by Wednesday, I would have started scheduling people. And then, obviously, the easy ones, like Mala day, Steve and I'd have locked them in three, just the other ones, like this guy and the HR person, like who asked what they But ideally, we will try and do all the interviews this week. Okay,

Nicholas Folarin-Coker  
so in terms of deliverables, we're saying a landing page based off of the respective styles, one two, saying a one pager, which has no more than 25 questions that they can look at, so that they are prepared to answer the questions for this call three, we probably need some kind of calendar booking page so that they can book in time that suits them. I should be able to do that as well. You

Timilehin Tikolo  
see a booking page for them. No, no, we don't need a page for them.

Nicholas Folarin-Coker  
I need a page. Okay, then we'll try. But okay, no worries. I

Timilehin Tikolo  
could just put that on our calendar. Do you know? I mean, like, yeah, no

Nicholas Folarin-Coker  
problem, yeah. Um, okay, so it's two, two deliverables, and then what the things that we because obviously there's deliverables, and it seems that we still have undecided. I'm sure the note taker in this call will also make it, but it's just off the top of my head. It's what are we going to do with this six month offer? Who are we going? No, we've already found the four people that we're going to speak to regarding the sales training, we've already decided that sales training is the first thing. Are we in agreement that the sales training should be broken up into two things? What part being foundational and part being specific to operational staff on the floor? Or do you think it should just be one?

Timilehin Tikolo  
Um, the sales training at this point to just be sales, front facing, sales, okay, cool, foundation skills like engagement, handling, Objection, all that kind of stuff, a bit operational at this stage would be The store management, side manager. So,

Nicholas Folarin-Coker  
yeah, that's the second one, yeah. Just like the comments, you know, okay, cool.

Timilehin Tikolo  
Um, sorry that that one is in the like, the social training we're doing now is because it's for the Store team. Yeah, the store manager,

Nicholas Folarin-Coker  
oh, it's both okay

Timilehin Tikolo  
for them. I because the store manager thing is everything we're doing just plus a few more things for like administrative management, right? All that is now. Then things fall much later than the back end supporting units, like buying, inventory management, customer experience, right those department performance management that that one will then build off. That's when it becomes like a full fledged retail support. Right now it's just like we're doing full 360 retail support. Cool. But right now

Nicholas Folarin-Coker  
we're starting building

Timilehin Tikolo  
into training, yeah,

Nicholas Folarin-Coker  
okay, cool, okay. Is there anything that you feel that I've missed or that it's still up in the air?

Timilehin Tikolo  
No, I think we're very aligned at this stage. Actually, I think even with the and I'll say this up for the note taker, so that I can win the transcriber and remember as well, on the on the on the six months contract. I need to almost lay out, in terms of like, what look like monthly, over six months, how we can maybe realistically add in sales training side a time that overlaps the when we think the programme will be ready, so it could be like, by month four or supporting their business will then do the sales training ready for like, month three. Do you know, I mean, but the first, the first two months were just like, doing diagnostics, SOP, you know, I mean,

Nicholas Folarin-Coker  
and then, like, okay, okay, no problem. And that's we're not. We're no longer looking at, potentially at being abroad. This is to be in Lagos. Or are you saying this roadmap, version A for in Nigeria, and version B being somewhere else in Africa.

Timilehin Tikolo  
I'm just saying Nigeria for now.

Nicholas Folarin-Coker  
That's just asking

you say that plus 775, Guinea. Yeah, okay, cool, yeah, I will, yeah, I'll get this all tabulated, and then yeah, we can move forward. I think, I think this has been very productive. Yeah, I agree as well. I gotta run back and send this email. But, yeah, I'm hoping I'm hoping that I'll have something shitty to show you end of today, okay and it was just yeah, we'll just keep it straight. I love our end of it.

